declare module "@salesforce/apex/AgentChatController.chat" {
  export default function chat(param: {message: any, sessionId: any}): Promise<any>;
}
