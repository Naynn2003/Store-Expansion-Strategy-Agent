declare module "@salesforce/apex/DashboardController.getSummaryMetrics" {
  export default function getSummaryMetrics(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.getMarkets" {
  export default function getMarkets(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.getSites" {
  export default function getSites(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.getCompetitors" {
  export default function getCompetitors(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.getFinancials" {
  export default function getFinancials(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.getScores" {
  export default function getScores(): Promise<any>;
}
declare module "@salesforce/apex/DashboardController.chat" {
  export default function chat(param: {message: any}): Promise<any>;
}
