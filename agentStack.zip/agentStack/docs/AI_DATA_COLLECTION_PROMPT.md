# AI Data Collection Prompt — Store Expansion Strategy Agent
> **Instructions for AI**: Read this entire file carefully. Use your internet search / web knowledge to fill in the requested data for each object. Output exact CSV content as specified. Do not invent data — use real, verifiable sources for India retail/FMCG market data.

---

## Project Context

We are building a **Salesforce Agentforce agent** for an Indian retail chain (similar to DMart / Reliance Smart) to decide which cities and locations to open new stores in. The Salesforce org has 9 custom objects already deployed.

We have already loaded **49 demographic records** (`Demographic_Data__c`) — one per pin code across 23 Indian cities. Now we need to load bulk static data for 7 more objects.

**Your job**: Research real market data for these 23 cities and output CSV files for each object as described below.

---

## Cities In Scope (23 cities — from existing demographic data)

> These are the ONLY cities you should generate data for. Use the demographic stats below as context when filling market/site fields.

| # | City | State | Region | Pin Codes We Have | Avg HH Income (₹/yr) | Pop Density (per km²) | Income Bracket | Literacy % |
|---|------|-------|--------|-------------------|---------------------|----------------------|----------------|------------|
| 1 | Mumbai | Maharashtra | West | 400064, 400058, 400069, 400053, 400047, 400062, 400097, 400091, 400028, 400050, 400037, 400022 | 52,000 | 20,038 | Upper-Middle | 88.98 |
| 2 | Pune | Maharashtra | West | 411001, 411045, 411007, 411038, 411005 | 42,000–58,000 | 603–18,500 | Middle–Upper-Middle | 87.19–91.20 |
| 3 | Bangalore | Karnataka | South | 560001, 560038 | 55,000 | 4,381 | Upper-Middle | 88.48 |
| 4 | Hyderabad | Telangana | South | 500001, 500081 | 38,000 | 18,172 | Middle | 83.25 |
| 5 | Delhi | Delhi | North | 110001, 110024 | 58,000 | 11,320 | Upper-Middle | 86.34 |
| 6 | Chennai | Tamil Nadu | South | 600001, 600093 | 40,000 | 26,702 | Middle | 90.33 |
| 7 | Ahmedabad | Gujarat | West | 380001, 380015 | 42,000 | 891 | Middle | 85.31 |
| 8 | Gandhinagar | Gujarat | West | 382010 | 45,000 | 2,138 | Middle | 88.74 |
| 9 | Surat | Gujarat | West | 395001, 395007 | 48,000 | 1,384 | Upper-Middle | 85.53 |
| 10 | Vadodara | Gujarat | West | 390001 | 40,000 | 552 | Middle | 84.76 |
| 11 | Bhopal | Madhya Pradesh | Central | 462001, 462016 | 35,000 | 855 | Middle | 82.25 |
| 12 | Indore | Madhya Pradesh | Central | 452001, 452010 | 38,000 | 839 | Middle | 82.37 |
| 13 | Gwalior | Madhya Pradesh | Central | 474001 | 28,000 | 445 | Low | 76.18 |
| 14 | Jabalpur | Madhya Pradesh | Central | 482001 | 28,000 | 242 | Low | 79.88 |
| 15 | Lucknow | Uttar Pradesh | North | 226001, 226010 | 32,000 | 1,815 | Middle | 77.29 |
| 16 | Kanpur | Uttar Pradesh | North | 208001 | 30,000 | 1,449 | Middle | 79.65 |
| 17 | Agra | Uttar Pradesh | North | 282001 | 28,000 | 1,097 | Low | 70.76 |
| 18 | Varanasi | Uttar Pradesh | North | 221001 | 25,000 | 2,330 | Low | 75.60 |
| 19 | Noida | Uttar Pradesh | North | 201301, 201304 | 65,000 | 1,299 | Upper-Middle | 80.12 |
| 20 | Jaipur | Rajasthan | North | 302001, 302020 | 35,000 | 595 | Middle | 75.51 |
| 21 | Jodhpur | Rajasthan | North | 342001 | 28,000 | 161 | Low | 65.94 |
| 22 | Udaipur | Rajasthan | North | 313001 | 28,000 | 228 | Low | 62.98 |
| 23 | Kota | Rajasthan | North | 324001 | 32,000 | 374 | Middle | 77.48 |

---

## Field Legend

> Before generating any CSV, understand these three categories:

| Symbol | Meaning |
|--------|---------|
| ✅ FILL | You must provide this value — research it or derive it logically |
| 🔴 SKIP (API) | Do NOT include — will be fetched live via Google Places / Maps API later |
| 🟡 SKIP (Formula) | Do NOT include — Salesforce auto-calculates this field |
| 🔵 SKIP (FK) | Do NOT include — Foreign Key will be wired separately after load |

---

## Object 1: `Market_Analysis__c`
**One record per city (23 records total)**

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Name` | Name | Text | Format: `"[City] Market Analysis"` e.g. `"Mumbai Market Analysis"` |
| `City__c` | City | Text(100) | City name from city list above |
| `State__c` | State | Text(100) | State from city list above |
| `Region__c` | Region | Picklist | Must be one of: `North`, `South`, `East`, `West`, `Central` — use city list |
| `TAM__c` | Total Addressable Market | Currency (INR) | **Research**: FMCG/grocery retail TAM in INR crores for that city's metro area. Use IBEF, Technopak, or Euromonitor India reports. Convert to INR (not crores — actual number, e.g. 150000000000 for ₹1,500 Cr) |
| `Analysis_Date__c` | Analysis Date | Date | Use `2026-04-01` for all records |
| `Top_Sites__c` | Top Sites Summary | LongTextArea | **Research**: Write 2–3 sentences naming the best 2 localities/areas in this city for opening a new grocery/FMCG supermarket. Mention actual neighbourhood names. |
| `Blind_Spots__c` | Blind Spots Summary | LongTextArea | **Research**: Write 2–3 sentences on the top retail risks or challenges specific to this city (e.g. heavy organised retail competition, low footfall zones, logistics issues, local regulatory) |
| `Primary_Source__c` | Primary Source | Text(255) | Name of source used (e.g. `IBEF Retail Report 2024`, `Technopak India Retail 2024`) |
| `Source_Version__c` | Source Version | Text(80) | Version/date of source (e.g. `2024 edition`) |
| `Confidence__c` | Confidence | Picklist | Must be one of: `High`, `Medium`, `Low` — set `Medium` if from public reports, `Low` if estimated |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Growth_Rate__c` | 🔴 SKIP (API) — will be fetched from World Bank / MOSPI GDP growth API |
| `Competitor_Count__c` | 🔴 SKIP (API) — will be fetched from Google Places nearby search count |

### CSV header:
```
Name,City__c,State__c,Region__c,TAM__c,Analysis_Date__c,Top_Sites__c,Blind_Spots__c,Primary_Source__c,Source_Version__c,Confidence__c
```

---

## Object 2: `Market_Top_Site__c`
**2–3 records per city (46–69 records total). Child of Market_Analysis__c.**

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Name` | Name | Text | Format: `"[City] Top Site [Rank]"` e.g. `"Mumbai Top Site 1"` |
| `Market_Analysis_Name__c` | *(Reference column)* | Text | Put the `Name` value of the parent Market_Analysis record (e.g. `"Mumbai Market Analysis"`). This column is used post-load to wire the lookup — do NOT name it `Market_Analysis__c` |
| `Site_Name__c` | Site Name | Text(255) | **Research**: Real locality name + pin code in that city. e.g. `"Malad West - 400064"`. Pick from our existing pin code list if possible, otherwise name a real location. |
| `Rank__c` | Rank | Number | Integer 1, 2, or 3 |
| `Demand_Score__c` | Demand Score | Number(5,2) | Score 0–100. Derive from population density + income bracket from demographic table above. High density + Upper-Middle = 80+, Low density + Low income = 40–55 |
| `Revenue_Potential__c` | Revenue Potential | Currency (INR/month) | **Research**: Estimate monthly revenue potential for a mid-size (5000–8000 sqft) FMCG supermarket in that locality. Use comparable DMart/Reliance store revenues as benchmark. |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Market_Analysis__c` | 🔵 SKIP (FK) — wired separately using `Market_Analysis_Name__c` after load |

### CSV header:
```
Name,Market_Analysis_Name__c,Site_Name__c,Rank__c,Demand_Score__c,Revenue_Potential__c
```

---

## Object 3: `Market_Risk__c`
**2–3 records per city (46–69 records total). Child of Market_Analysis__c.**

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Name` | Name | Text | Format: `"[City] Risk [Number]"` e.g. `"Mumbai Risk 1"` |
| `Market_Analysis_Name__c` | *(Reference column)* | Text | Parent Market_Analysis Name (e.g. `"Mumbai Market Analysis"`) |
| `Risk_Type__c` | Risk Type | Picklist | Must be one of: `Demand`, `Competition`, `Accessibility`, `Supply`, `Demographics` |
| `Severity__c` | Severity | Picklist | Must be one of: `High`, `Medium`, `Low` |
| `Summary__c` | Summary | LongTextArea | **Research**: 1–2 sentence description of the specific risk for this city. Be specific — e.g. for Mumbai Competition risk: "High density of organised retail including 20+ DMart and Reliance Smart outlets in western suburbs reduces captive market share." |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Market_Analysis__c` | 🔵 SKIP (FK) — wired separately |

### CSV header:
```
Name,Market_Analysis_Name__c,Risk_Type__c,Severity__c,Summary__c
```

---

## Object 4: `Expansion_Site__c`
**1–2 candidate sites per city (23–46 records total)**

> Pick real, specific addresses — ideally high-street retail locations, near main markets or residential clusters.

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Name` | Name | Text | Format: `"[Locality] - [Pin]"` e.g. `"Malad West - 400064"` |
| `Address__c` | Address | TextArea | **Research**: A real, specific street address suitable for a retail store in that locality. |
| `City__c` | City | Text(100) | City name |
| `State__c` | State | Text(100) | State name |
| `Pin_Code__c` | Pin Code | Text(6) | 6-digit pin code — use one from our demographic list for that city where possible |
| `Region__c` | Region | Picklist | `North` / `South` / `East` / `West` / `Central` |
| `Area_Type__c` | Area Type | Picklist | Must be one of: `Metro`, `Tier 1`, `Tier 2`, `Tier 3`, `Rural`. Mumbai/Delhi/Bangalore/Hyderabad/Chennai = Metro. Pune/Ahmedabad/Surat/Jaipur/Lucknow = Tier 1. Others = Tier 2. |
| `Latitude__c` | Latitude | Number(10,7) | **Research**: Real latitude of the address (7 decimal places). e.g. `19.1864162` |
| `Longitude__c` | Longitude | Number(11,7) | **Research**: Real longitude of the address (7 decimal places). e.g. `72.8493388` |
| `Setup_Cost__c` | Setup Cost | Currency (INR) | Estimate in INR. Metro ~₹2–4 Cr, Tier 1 ~₹1–2 Cr, Tier 2 ~₹50L–1 Cr |
| `Payback_Period_Months__c` | Payback Period | Number | Estimate months to break even. Metro 24–36, Tier 1 18–30, Tier 2 12–24 |
| `Status__c` | Status | Picklist | Set `Identified` for all |
| `Recommended__c` | Recommended | Checkbox | `true` for Rank 1 top sites, `false` otherwise |
| `Population_Density__c` | Population Density | Number | Use value from demographic table above for that city/pin code |
| `Avg_Household_Income__c` | Avg Household Income | Currency | Use value from demographic table above for that city |
| `Est_Monthly_Revenue__c` | Est Monthly Revenue | Currency (INR) | Estimate: Metro ₹1.5–3 Cr/month, Tier 1 ₹80L–1.5 Cr, Tier 2 ₹40–80L |
| `Accessibility_Score__c` | Accessibility Score | Number(3,0) | Score 0–100. High road connectivity + public transport + parking = 80+. Remote = 40–60. |
| `Competition_Level__c` | Competition Level | Picklist | Must be one of: `High`, `Medium`, `Low`. Research: are there many organised retailers (DMart, Reliance, BigBazaar) already in that pin code? |
| `Notes__c` | Notes | LongTextArea | 1–2 sentences: why this site was identified, any special advantage |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Foot_Traffic_Index__c` | 🔴 SKIP (API) — Google Popular Times API |
| `Distance_Nearest_Store_km__c` | 🔴 SKIP (API) — Google Maps Distance Matrix API |
| `Demand_Score__c` | 🔴 SKIP (API) — calculated from foot traffic |
| `Est_Annual_Revenue__c` | 🟡 SKIP (Formula) — auto-calculated as Est_Monthly_Revenue__c × 12 |
| `Account__c` | 🔵 SKIP (FK) — wired to "Retail Strategy India Pvt Ltd" post-load |
| `Demographic_Area__c` | 🔵 SKIP (FK) — wired to matching Demographic_Data__c post-load |
| `Nearest_Store__c` | 🔵 SKIP (FK) — wired to nearest RetailStore post-load |

### CSV header:
```
Name,Address__c,City__c,State__c,Pin_Code__c,Region__c,Area_Type__c,Latitude__c,Longitude__c,Setup_Cost__c,Payback_Period_Months__c,Status__c,Recommended__c,Population_Density__c,Avg_Household_Income__c,Est_Monthly_Revenue__c,Accessibility_Score__c,Competition_Level__c,Notes__c
```

---

## Object 5: `Competitor_Store__c`
**3–5 stores per city (69–115 records total)**

> Use real, named competitor stores — DMart, Reliance Smart, Reliance Fresh, Big Bazaar, Star Bazaar, More Supermarket, Spencer's, Lulu, SPAR, D-Mart, etc.

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Name` | Name | Text | Format: `"[Brand] [Locality]"` e.g. `"DMart Malad West"` |
| `Brand__c` | Brand | Text(255) | **Research**: Real brand name. e.g. `DMart`, `Reliance Smart`, `Big Bazaar`, `Spencer's`, `Star Bazaar`, `More Supermarket`, `Lulu Hypermarket`, `SPAR` |
| `Category__c` | Category | Picklist | Must be one of: `FMCG`, `Electronics`, `Fashion`, `General`, `Pharmacy`. Grocery/supermarkets = `FMCG` |
| `Address__c` | Address | TextArea | **Research**: Real address of that store |
| `City__c` | City | Text(100) | City name |
| `State__c` | State | Text(100) | State name |
| `Pin_Code__c` | Pin Code | Text(6) | Pin code of that store's location |
| `Store_Format__c` | Store Format | Picklist | Must be one of: `Supermarket`, `Express`, `Hypermarket`, `Kirana`, `Online Dark Store`. DMart = Hypermarket, Reliance Fresh = Supermarket, Reliance Smart = Hypermarket |
| `Store_Size_Sqft__c` | Store Size (sqft) | Number | **Research**: Approx store size. DMart Hypermarket ~30,000–50,000 sqft, Reliance Smart ~8,000–15,000 sqft, Reliance Fresh ~2,000–4,000 sqft |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Latitude__c` | 🔴 SKIP (API) — Google Places API |
| `Longitude__c` | 🔴 SKIP (API) — Google Places API |
| `Geolocation__c` | 🔴 SKIP (API) — Google Places API |
| `Rating__c` | 🔴 SKIP (API) — Google Places rating |
| `Distance_km__c` | 🔴 SKIP (API) — Google Maps Distance Matrix |
| `Est_Monthly_Revenue__c` | 🔴 SKIP (API) — derived from rating + size |
| `Nearest_Expansion_Site__c` | 🔵 SKIP (FK) — wired post-load |

### CSV header:
```
Name,Brand__c,Category__c,Address__c,City__c,State__c,Pin_Code__c,Store_Format__c,Store_Size_Sqft__c
```

---

## Object 6: `Site_Score__c`
**1 record per Expansion_Site (same count as Object 4)**

> Scores are 0–25 per factor (4 factors, max total 100). Base your scores on the demographic and market context for that city.

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Expansion_Site_Name__c` | *(Reference column)* | Text | Name of parent Expansion_Site record (e.g. `"Malad West - 400064"`) |
| `Scoring_Date__c` | Scoring Date | Date | Use `2026-04-15` |
| `Scored_By__c` | Scored By | Text(100) | `Agentforce Store Expansion Agent` |
| `Demand_Factor__c` | Demand Factor | Number(2,0) | Score 0–25. Based on population density + income + age 18–35 % from demographic table |
| `Demographics_Factor__c` | Demographics Factor | Number(2,0) | Score 0–25. Based on literacy + income bracket + working population % from demographic table |
| `Competition_Factor__c` | Competition Factor | Number(2,0) | Score 0–25. **Inverse** of competition density. Low competition = high score. High competition city = 8–12, Low = 18–22 |
| `Accessibility_Factor__c` | Accessibility Factor | Number(2,0) | Score 0–25. Use same logic as `Accessibility_Score__c` in Expansion_Site, mapped to 0–25 range |
| `Scoring_Notes__c` | Scoring Notes | LongTextArea | 1–2 sentences explaining the overall score reasoning |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Total_Score__c` | 🟡 SKIP (Formula) — auto-calculated as sum of 4 factors |
| `Expansion_Site__c` | 🔵 SKIP (FK) — wired using `Expansion_Site_Name__c` post-load |

### CSV header:
```
Expansion_Site_Name__c,Scoring_Date__c,Scored_By__c,Demand_Factor__c,Demographics_Factor__c,Competition_Factor__c,Accessibility_Factor__c,Scoring_Notes__c
```

---

## Object 7: `Financial_Projection__c`
**1 record per Expansion_Site (same count as Object 4)**

### Fields to FILL (include in CSV):
| CSV Column | Salesforce Field | Type | Instructions |
|---|---|---|---|
| `Expansion_Site_Name__c` | *(Reference column)* | Text | Name of parent Expansion_Site record |
| `Projection_Date__c` | Projection Date | Date | Use `2026-04-15` |
| `Setup_Cost__c` | Setup Cost | Currency (INR) | Same value as Setup_Cost__c on the Expansion_Site record |
| `Monthly_Rent__c` | Monthly Rent | Currency (INR) | **Research**: Market rental rates for ~5000–8000 sqft retail in that locality. Metro ₹3–8L/month, Tier 1 ₹1.5–3L, Tier 2 ₹50K–1.5L |
| `Monthly_Operating__c` | Monthly Operating Cost | Currency (INR) | Staff + utilities + logistics. Metro ~₹15–25L, Tier 1 ~₹8–15L, Tier 2 ~₹4–8L |
| `Monthly_Revenue__c` | Monthly Revenue | Currency (INR) | Same as `Est_Monthly_Revenue__c` on Expansion_Site |
| `Revenue_Confidence__c` | Revenue Confidence | Picklist | Must be one of: `High`, `Medium`, `Low`. Use `Medium` unless exceptional location |
| `Assumptions__c` | Assumptions | LongTextArea | 2–3 bullet points: store size assumed, revenue/sqft benchmark used, rent source |

### Fields to SKIP:
| Field | Reason |
|---|---|
| `Monthly_Profit__c` | 🟡 SKIP (Formula) — auto: Monthly_Revenue__c − Monthly_Rent__c − Monthly_Operating__c |
| `Payback_Months__c` | 🟡 SKIP (Formula) — auto: Setup_Cost__c / Monthly_Profit__c |
| `Expansion_Site__c` | 🔵 SKIP (FK) — wired post-load |
| `Comparable_Store__c` | 🔵 SKIP (FK) — wired to nearest RetailStore post-load |

### CSV header:
```
Expansion_Site_Name__c,Projection_Date__c,Setup_Cost__c,Monthly_Rent__c,Monthly_Operating__c,Monthly_Revenue__c,Revenue_Confidence__c,Assumptions__c
```

---

## Output Format Rules

1. **Encoding**: UTF-8
2. **Delimiter**: comma
3. **Text quoting**: Wrap any field containing commas or newlines in double quotes
4. **Currency fields**: Plain numbers only — no ₹ symbol, no commas. e.g. `52000` not `₹52,000`
5. **Date fields**: ISO format `YYYY-MM-DD`
6. **Checkbox fields**: `true` or `false` (lowercase)
7. **One CSV per object** — do not combine objects
8. **File names to use**:
   - `market_analysis.csv`
   - `market_top_sites.csv`
   - `market_risks.csv`
   - `expansion_sites.csv`
   - `competitor_stores.csv`
   - `site_scores.csv`
   - `financial_projections.csv`

---

## Data Sources to Use for Research

| Data type | Recommended sources |
|---|---|
| Retail TAM by city | IBEF Retail India report, Technopak India Retail Outlook, Euromonitor India |
| Store locations (competitor) | Google Maps, JustDial, DMart investor reports, Reliance Retail store locator |
| Rental rates by city | 99acres commercial listings, Magicbricks, JLL India retail report |
| Lat/Long | Google Maps (right-click → coordinates), OpenStreetMap |
| City-level retail risk | CBRE India retail report, Knight Frank India retail, news articles |
| Revenue benchmarks | DMart annual report (Revenue/sqft: ~₹30,000–40,000/sqft/year), Reliance Retail annual report |

---

## Important Constraints

- **Picklist values are STRICT** — only use the exact values listed. Any other value will fail on load.
- **Do not generate records for cities outside the 23-city list above.**
- **Do not fill SKIP fields** — those columns must be absent from the CSV entirely.
- **Reference columns** (`Market_Analysis_Name__c`, `Expansion_Site_Name__c`) are helper columns for post-load FK wiring — they are NOT Salesforce field API names.
- **Currency is INR** — all monetary values in Indian Rupees as plain integers.
